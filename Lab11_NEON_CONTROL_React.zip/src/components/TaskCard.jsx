export default function TaskCard({ task, onMove, onDelete, canMoveLeft, canMoveRight }) {
  return (
    <article className="task-card">
      <div className="task-top"><span className={`priority-dot ${task.priority}`} /> <span className="task-priority">{task.priorityLabel}</span>
        <button className="icon-button delete-button" type="button" onClick={() => onDelete(task.id)} aria-label="Удалить задачу">×</button>
      </div>
      <h4>{task.title}</h4>
      {task.note && <p>{task.note}</p>}
      <div className="task-actions">
        <button type="button" disabled={!canMoveLeft} onClick={() => onMove(task.id, -1)}>← Назад</button>
        <button type="button" disabled={!canMoveRight} onClick={() => onMove(task.id, 1)}>Далее →</button>
      </div>
    </article>
  );
}