export default function ThemeSwitch({ theme, onToggle, lightLabel, darkLabel }) {
  const isDark = theme === 'dark';
  return (
    <button className="theme-switch" onClick={onToggle} type="button" aria-label="Переключить тему">
      <span className="theme-icon">{isDark ? '☾' : '☀'}</span>
      <span>{isDark ? darkLabel : lightLabel}</span>
      <span className={`switch-track ${isDark ? 'active' : ''}`}><i /></span>
    </button>
  );
}