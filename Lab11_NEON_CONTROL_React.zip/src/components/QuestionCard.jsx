export default function QuestionCard({ question, selected, onSelect, questionNumber, total }) {
  return (
    <article className="question-card">
      <div className="question-meta"><span>ВОПРОС {String(questionNumber).padStart(2, '0')}</span><span>{questionNumber} / {total}</span></div>
      <h3>{question.text}</h3>
      <div className="answers">
        {question.options.map((option, index) => (
          <button
            type="button"
            key={option}
            className={`answer ${selected === index ? 'chosen' : ''}`}
            onClick={() => onSelect(index)}
          >
            <span className="answer-letter">{String.fromCharCode(65 + index)}</span>
            <span>{option}</span>
            {selected === index && <span className="answer-check">✓</span>}
          </button>
        ))}
      </div>
    </article>
  );
}