import { useEffect, useMemo, useState } from 'react';
import ThemeSwitch from './components/ThemeSwitch.jsx';
import QuestionCard from './components/QuestionCard.jsx';
import TaskCard from './components/TaskCard.jsx';

const quizQuestions = [
  { text: 'Какой хук React используют для локального состояния?', options: ['useEffect', 'useState', 'useMemo', 'useRef'], correct: 1 },
  { text: 'Для чего предназначены props?', options: ['Для передачи данных компоненту', 'Для оформления CSS', 'Для запуска сервера', 'Для хранения файлов'], correct: 0 },
  { text: 'Что вызывает повторный рендер компонента?', options: ['Изменение обычной переменной', 'Изменение CSS', 'Изменение state или props', 'Перезагрузка браузера'], correct: 2 },
  { text: 'Как правильно обработать нажатие кнопки?', options: ['click="run"', 'onClick={handleClick}', 'onclick: handleClick()', 'run.onClick'], correct: 1 }
];

const initialTasks = [
  { id: 1, title: 'Собрать структуру проекта', note: 'Создать компоненты и подключить стили', status: 0, priority: 'high', priorityLabel: 'Высокий' },
  { id: 2, title: 'Изучить props и state', note: 'Подготовить объяснение для защиты', status: 1, priority: 'medium', priorityLabel: 'Средний' },
  { id: 3, title: 'Проверить адаптивность', note: 'Мобильная и широкая версия', status: 2, priority: 'low', priorityLabel: 'Низкий' }
];

const columns = ['К выполнению', 'В процессе', 'Готово'];

function readStorage(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [theme, setTheme] = useState(() => readStorage('neon-theme', 'dark'));
  const [tasks, setTasks] = useState(() => readStorage('neon-tasks', initialTasks));
  const [newTitle, setNewTitle] = useState('');
  const [newNote, setNewNote] = useState('');
  const [priority, setPriority] = useState('medium');
  const [filter, setFilter] = useState('all');
  const [quizIndex, setQuizIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [quizFinished, setQuizFinished] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => { localStorage.setItem('neon-theme', JSON.stringify(theme)); }, [theme]);
  useEffect(() => { localStorage.setItem('neon-tasks', JSON.stringify(tasks)); }, [tasks]);

  const completed = tasks.filter(task => task.status === 2).length;
  const inProgress = tasks.filter(task => task.status === 1).length;
  const visibleTasks = useMemo(
    () => tasks.filter(task => filter === 'all' || task.priority === filter),
    [tasks, filter]
  );

  function addTask(event) {
    event.preventDefault();
    const title = newTitle.trim();
    if (!title) {
      setNotice('Введите название задачи, прежде чем добавлять её.');
      return;
    }
    const labels = { high: 'Высокий', medium: 'Средний', low: 'Низкий' };
    setTasks(current => [...current, {
      id: Date.now(), title, note: newNote.trim(), status: 0,
      priority, priorityLabel: labels[priority]
    }]);
    setNewTitle('');
    setNewNote('');
    setNotice('Задача добавлена в очередь.');
  }

  function moveTask(id, direction) {
    setTasks(current => current.map(task =>
      task.id === id ? { ...task, status: Math.max(0, Math.min(2, task.status + direction)) } : task
    ));
  }

  function deleteTask(id) {
    setTasks(current => current.filter(task => task.id !== id));
    setNotice('Задача удалена.');
  }

  function chooseAnswer(optionIndex) {
    if (quizFinished) return;
    setAnswers(current => ({ ...current, [quizIndex]: optionIndex }));
  }

  function nextQuestion() {
    if (answers[quizIndex] === undefined) {
      setNotice('Сначала выберите один вариант ответа.');
      return;
    }
    setNotice('');
    if (quizIndex < quizQuestions.length - 1) setQuizIndex(index => index + 1);
    else setQuizFinished(true);
  }

  function resetQuiz() {
    setQuizIndex(0);
    setAnswers({});
    setQuizFinished(false);
    setNotice('Викторина начата заново.');
  }

  const score = quizQuestions.reduce((sum, question, index) =>
    sum + (answers[index] === question.correct ? 1 : 0), 0);

  return (
    <main className={`app-shell ${theme}`}>
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <a className="brand" href="#top"><span className="brand-mark">N</span><span>NEON<span className="brand-muted">/</span>CONTROL</span></a>
        <div className="topbar-right"><span className="live-status"><i /> SYSTEM ONLINE</span>
          <ThemeSwitch theme={theme} onToggle={() => setTheme(value => value === 'dark' ? 'light' : 'dark')} lightLabel="Светлая" darkLabel="Тёмная" />
        </div>
      </header>

      <section className="hero" id="top">
        <div>
          <div className="eyebrow"><span className="eyebrow-line" /> LABORATORY WORK №11 <span className="eyebrow-year">2026</span></div>
          <h1>Твоя работа.<br /><span>Под твоим контролем.</span></h1>
          <p className="hero-copy">Интерактивная панель на React. Управляй задачами, проверяй знания и наблюдай, как интерфейс реагирует на каждое действие.</p>
        </div>
        <div className="hero-orbit" aria-hidden="true"><div className="orbit-ring ring-a" /><div className="orbit-ring ring-b" /><div className="orbit-core">N<span>11</span></div><i className="orbit-point point-a" /><i className="orbit-point point-b" /></div>
      </section>

      <section className="stats-grid" aria-label="Статистика задач">
        <div className="stat-card"><span className="stat-label">ВСЕГО ЗАДАЧ</span><strong>{tasks.length.toString().padStart(2, '0')}</strong><span className="stat-foot">В твоём пространстве</span></div>
        <div className="stat-card"><span className="stat-label">В ПРОЦЕССЕ</span><strong>{inProgress.toString().padStart(2, '0')}</strong><span className="stat-foot">Уже в работе</span></div>
        <div className="stat-card accent-stat"><span className="stat-label">ЗАВЕРШЕНО</span><strong>{completed.toString().padStart(2, '0')}</strong><span className="stat-foot">Доведено до результата</span></div>
        <div className="stat-card"><span className="stat-label">ПРОГРЕСС</span><strong>{tasks.length ? Math.round(completed / tasks.length * 100) : 0}<small>%</small></strong><div className="mini-progress"><i style={{ width: `${tasks.length ? completed / tasks.length * 100 : 0}%` }} /></div></div>
      </section>

      <section className="section-block">
        <div className="section-heading"><div><span className="section-index">01 / BASE LEVEL</span><h2>Режим интерфейса</h2></div><span className="section-tag">ВАРИАНТ 03 · THEMESWITCH</span></div>
        <div className="theme-panel"><div className="theme-preview"><div className="preview-window"><div className="preview-bar"><i /><i /><i /><span>PREVIEW.SYS</span></div><div className="preview-content"><div className="preview-chip" /><div className="preview-line long" /><div className="preview-line" /><div className="preview-line short" /></div></div></div><div className="theme-description"><span className="tiny-label">LIVE APPEARANCE</span><h3>{theme === 'dark' ? 'Ночная смена' : 'Дневной режим'}</h3><p>{theme === 'dark' ? 'Глубокий фон и яркие акценты. Всё внимание на содержимом.' : 'Светлая поверхность и спокойный контраст для работы днём.'}</p><button className="primary-button" type="button" onClick={() => setTheme(value => value === 'dark' ? 'light' : 'dark')}>Переключить тему <span>↗</span></button></div></div>
      </section>

      <section className="section-block">
        <div className="section-heading"><div><span className="section-index">02 / INTERMEDIATE LEVEL</span><h2>Проверка знаний</h2></div><span className="section-tag">ВАРИАНТ 15 · MINI QUIZ</span></div>
        <div className="quiz-layout"><div className="quiz-side"><span className="quiz-symbol">?</span><span className="tiny-label">KNOWLEDGE CHECK</span><h3>React<br />без секретов.</h3><p>Ответь на вопросы о компонентах, props и state. Результат появится после последнего вопроса.</p><div className="quiz-progress-label"><span>ПРОГРЕСС</span><b>{quizFinished ? 100 : Math.round(Object.keys(answers).length / quizQuestions.length * 100)}%</b></div><div className="progress-track"><i style={{ width: `${quizFinished ? 100 : Object.keys(answers).length / quizQuestions.length * 100}%` }} /></div></div>
          <div className="quiz-main">{quizFinished ? <div className="result-panel"><span className="result-icon">{score >= 3 ? '✦' : '↗'}</span><span className="tiny-label">ТЕСТ ЗАВЕРШЁН</span><strong>{score}<small> / {quizQuestions.length}</small></strong><h3>{score === 4 ? 'Идеальный результат!' : score >= 2 ? 'Хорошая работа!' : 'Есть куда расти.'}</h3><p>Правильных ответов: {score} из {quizQuestions.length}.</p><button className="primary-button" type="button" onClick={resetQuiz}>Пройти ещё раз ↻</button></div> : <><QuestionCard question={quizQuestions[quizIndex]} selected={answers[quizIndex]} onSelect={chooseAnswer} questionNumber={quizIndex + 1} total={quizQuestions.length} /><div className="quiz-footer"><span>{Object.keys(answers).length} ИЗ {quizQuestions.length} ОТВЕТОВ</span><button className="primary-button" type="button" onClick={nextQuestion}>{quizIndex === quizQuestions.length - 1 ? 'Завершить тест' : 'Следующий вопрос'} <span>→</span></button></div></>}</div>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading"><div><span className="section-index">03 / ADVANCED LEVEL</span><h2>Доска задач</h2></div><span className="section-tag">ВАРИАНТ 19 · KANBAN</span></div>
        <div className="board-toolbar"><div><span className="tiny-label">WORKFLOW BOARD</span><p>Перемещай карточки по этапам и следи за прогрессом.</p></div><div className="filter-wrap"><label htmlFor="priority-filter">ФИЛЬТР</label><select id="priority-filter" value={filter} onChange={event => setFilter(event.target.value)}><option value="all">Все задачи</option><option value="high">Высокий приоритет</option><option value="medium">Средний приоритет</option><option value="low">Низкий приоритет</option></select></div></div>
        <form className="add-task-form" onSubmit={addTask}><div className="form-field title-field"><label htmlFor="task-title">НОВАЯ ЗАДАЧА</label><input id="task-title" value={newTitle} onChange={event => setNewTitle(event.target.value)} placeholder="Например, подготовить презентацию..." maxLength={70} /></div><div className="form-field note-field"><label htmlFor="task-note">КОММЕНТАРИЙ</label><input id="task-note" value={newNote} onChange={event => setNewNote(event.target.value)} placeholder="Краткое описание (необязательно)" maxLength={100} /></div><div className="form-field priority-field"><label htmlFor="task-priority">ПРИОРИТЕТ</label><select id="task-priority" value={priority} onChange={event => setPriority(event.target.value)}><option value="high">Высокий</option><option value="medium">Средний</option><option value="low">Низкий</option></select></div><button className="add-button" type="submit">+ Добавить</button></form>
        {notice && <p className="notice" role="status">{notice}</p>}
        <div className="kanban-board">{columns.map((column, columnIndex) => {
          const columnTasks = visibleTasks.filter(task => task.status === columnIndex);
          return <div className="kanban-column" key={column}><div className="column-heading"><div><i className={`column-indicator indicator-${columnIndex}`} /><h3>{column}</h3></div><span>{columnTasks.length.toString().padStart(2, '0')}</span></div><div className="column-content">{columnTasks.length ? columnTasks.map(task => <TaskCard key={task.id} task={task} onMove={moveTask} onDelete={deleteTask} canMoveLeft={columnIndex > 0} canMoveRight={columnIndex < 2} />) : <div className="empty-column">Здесь пока пусто <span>—</span></div>}</div></div>;
        })}</div>
      </section>

      <footer className="footer"><div className="brand footer-brand"><span className="brand-mark">N</span><span>NEON<span className="brand-muted">/</span>CONTROL</span></div><span>REACT · PROPS · STATE</span><span>LAB 11 <b>2026</b></span></footer>
    </main>
  );
}